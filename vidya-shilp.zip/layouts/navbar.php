<header class="header menu_2">
			<!-- <div id="preloader">
				<div data-loader="circle-side"></div>
			</div> -->
			<!-- /Preload -->
			<div id="logo">
				<div id="logo-container">
				<a href="index.php"><img src="img/logo.png" class="site-logo" alt=""></a>
			</div>
			</div>

			<!-- /top_menu -->
			<a href="#menu" class="btn_mobile">
				<div class="hamburger hamburger--spin" id="hamburger">
					<div class="hamburger-box">
						<div class="hamburger-inner"></div>
					</div>
				</div>
			</a>
			<nav id="menu" class="main-menu">
				<ul>
					<li><span><a href="index.php">Home</a></span></li>
					<li><span><a href="about-us.php">About Us</a></span></li>
					<li><span><a href="campus.php">Campus</a></span></li>
					<li><span><a href="academics.php">Academics</a></span></li>
					<li><span><a href="co-curriculars.php">Co-Curriculars</a></span></li>
					<li><span><a href="gallery.php">Gallery</a></span>
					<li><span><a href="testimonial.php">Testimonials</a></span>
					<li><span><a href="#">News Corner</a></span>
						<ul>
						
							<li><a href="blog.php">Blog</a></li>
							<li><a href="login.php">Events</a></li>
							
						</ul>
					</li>

					<li><span><a href="addmissions.php">Addmissions</a></span></li>
					<li class="desktop-hid"><span><a href="">E-Prospects</a></span></li>
					<li class="desktop-hid"><span><a href="">Enquire now</a></span></li>
					<li class="desktop-hid"><span><a href="">Contact Us</a></span></li>
					<li class="desktop-hid one-line"><a href=""><i class="fab fa-facebook-square"></i>
					</a><a href=""><i class="fab fa-instagram-square"></i>
					</a><a href=""><i class="fab fa-youtube-square"></i>
					</a><a href=""><i class="fab fa-linkedin"></i>
					</a></li>
					<li class="desktop-hid"><span><a href="mailto:admissions.vssb@vidyashilpschool.edu.in" style="font-size: 12px;"><i
						class="fas fa-envelope"></i> admissions.vssb@vidyashilpschool.edu.in</a></span></li>
					<li class="desktop-hid"><a href="tel:6366636624"><i class="fas fa-mobile-alt"></i>  6366636624</a></span></li>
					<li class="desktop-hid" style="padding: 0px 18px;
					color: white;">90/1, Chagalatti, Off Hennur-Bagalur Road, Bengaluru – 562149</li>
					<li class="desktop-hid" style="padding: 0px 18px;
					color: white;"><img src="./img/footer_logo.png" height="100px" alt=""></li>
					<li class="mob-hid">
						
						<button class="btn" type="button" data-bs-toggle="offcanvas"
							data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"><img src="img/menu.png" alt=""></button>

						<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight"
							aria-labelledby="offcanvasRightLabel">
							<div class="offcanvas-header">

								<h5 id="offcanvasRightLabel"></h5>
								<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
									aria-label="Close"></button>
							</div>
							<div class="offcanvas-body">
							<div class="d-flex flex-column bd-highlight mb-3">
								<p class="mb-1"><a href="#" class="top-links top-link-btn mb-2">E-Prospects</a></p>
								<p class="mb-1"><a href="#" class="top-links top-link-btn mb-2">Enquire now</a></p>
								<p class="mb-1"><a href="#" class="top-links top-link-btn mb-2">Contact Us</a></p>
								<p class="social-icon-togler d-flex mb-1"><a href=""><i class="fab fa-facebook-square"></i>
								</a><a href=""><i class="fab fa-instagram-square"></i>
								</a><a href=""><i class="fab fa-youtube-square"></i>
								</a><a href=""><i class="fab fa-linkedin"></i>
								</a></p>
								<p class="mb-1"><a href="tel:6366636624" class="top-links"><i class="fas fa-mobile-alt"></i>  6366636624</a></p>
								<p class="mb-1"><a href="mailto:admissions.vssb@vidyashilpschool.edu.in" class="top-links"><i
										class="fas fa-envelope"></i> admissions.vssb@vidyashilpschool.edu.in</a></p>
								<p class="text-offcanvas">90/1, Chagalatti, Off Hennur-Bagalur Road, Bengaluru – 562149</p>	
								<p class="text-center"><img src="./img/footer_logo.png" height="100px" alt=""></p>
							</div>
							</div>
						</div>
					</li>
				</ul>


			</nav>
			<!-- Search Menu -->
			<div class="search-overlay-menu">
				<span class="search-overlay-close"><span class="closebt"><i class="ti-close"></i></span></span>
				<form role="search" id="searchform" method="get">
					<input value="" name="q" type="search" placeholder="Search..." />
					<button type="submit"><i class="icon_search"></i>
					</button>
				</form>
			</div><!-- End Search Menu -->

		</header>