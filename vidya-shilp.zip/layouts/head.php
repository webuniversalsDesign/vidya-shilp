
	<!-- Favicons-->
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
	<link rel="apple-touch-icon" type="image/x-icon" href="img/favicon.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/favicon.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="114x114"
		href="img/favicon.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="144x144"
		href="img/favicon.png">

	<!-- ----fontawesome------ -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
		integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer" />
	<!-- GOOGLE WEB FONT -->
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap"
		rel="stylesheet">

	<!-- BASE CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/vendors.css" rel="stylesheet">


	<script src="https://kit.fontawesome.com/89650c467a.js" crossorigin="anonymous"></script>